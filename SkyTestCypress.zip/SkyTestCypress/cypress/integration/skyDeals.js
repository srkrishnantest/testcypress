/// <reference types = "cypress" />
it('check Deals', function() {
    cy.visit("https://www.sky.com/");
    cy.get('#sp_message_iframe_474555').then((iframe) => {
        const body = iframe.contents().find('body');
        cy.wrap(body).xpath("/html/body/div/div[2]/div[3]/button[2]").click();
    })
    cy.viewport(1280, 880);
    cy.xpath("//a[contains(text(),'Deals')]").click();
    cy.get('.box__Box-eb0ezq-0 > .Filter__Wrapper-sc-1xr0mo0-0 > .fRvmdt').should('contain.text','TV')
    cy.get('.box__Box-eb0ezq-0 > .Filter__Wrapper-sc-1xr0mo0-0 > .fRvmdt').click();
    cy.get('#deal-ultimate-tv > .jOIfJV > .Background-xf35qs-0 > .Content-sc-1kbz5vy-0 > .eTXizI').should('contain.text','Ultimate TV');
    cy.get('#deal-sky-tv-and-kids > .jOIfJV > .Background-xf35qs-0 > .Content-sc-1kbz5vy-0 > .eTXizI > .text__Text-sc-1u9gciq-0').should('contain.text','Sky TV & Kids');

    cy.get('.box__Box-eb0ezq-0 > .Filter__Wrapper-sc-1xr0mo0-0 > :nth-child(2)').click();
    cy.get('#deal-superfast-broadband > .jOIfJV > .Background-xf35qs-0 > .Content-sc-1kbz5vy-0 > .eTXizI > .text__Text-sc-1u9gciq-0').should('contain.text','Superfast Broadband');
    cy.get('#deal-ultrafast-broadband > .jOIfJV > .Background-xf35qs-0 > .Content-sc-1kbz5vy-0 > .eTXizI > .text__Text-sc-1u9gciq-0').should('contain.text','Ultrafast Broadband');

    cy.get('.box__Box-eb0ezq-0 > .Filter__Wrapper-sc-1xr0mo0-0 > :nth-child(3)').should('contain.text','Mobile');
    cy.get('.box__Box-eb0ezq-0 > .Filter__Wrapper-sc-1xr0mo0-0 > :nth-child(3)').click();
    cy.get('#deal-brilliant-iphone-12 > .jOIfJV > .Background-xf35qs-0 > .Content-sc-1kbz5vy-0 > .eTXizI > .text__Text-sc-1u9gciq-0').should('contain.text','Brilliant iPhone 12');
})