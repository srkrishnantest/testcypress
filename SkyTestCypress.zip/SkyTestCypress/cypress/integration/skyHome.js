/// <reference types = "cypress" />
/// <reference types = "Cypress-iframe" />

it('sky test', function(){
    cy.visit("https://www.sky.com/");
    //cy.frameLoaded('#sp_message_iframe_474555');
    //cy.xpath("/html/body/div/div[2]/div[3]/button[2]").click();
    cy.get('#sp_message_iframe_474555').then((iframe) => {
        const body = iframe.contents().find('body');
        cy.wrap(body).xpath("/html/body/div/div[2]/div[3]/button[2]").click();
        //cy.get('#burger-nav-toggle').click();
        //cy.get(':nth-child(5) > .nav-item-group > .nav-item-group-ctas > .nav-item-link').click();
        cy.viewport(1280, 880);
        cy.get('.user-menu-wrapper > .tab-focus').click();
        cy.get('#username').type('testuser');
        cy.get('#password').type('password');
        cy.get('#signinButton').click();
        cy.get('.page-header-two');
    })
})
//it('sky Deals', function(){
   
//})