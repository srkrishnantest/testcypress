/// <reference types = "cypress" />

it('Search Text', function() {
cy.visit("https://www.sky.com/");
cy.get('#sp_message_iframe_474555').then((iframe) => {
    const body = iframe.contents().find('body');
    cy.wrap(body).xpath("/html/body/div/div[2]/div[3]/button[2]").click();
    })
cy.viewport(1280,880);
cy.get('.search-toggle__icon').click();
cy.get('.c-form-input').type('Sky');
cy.wait(2000);
// cy.get('.c-form-input').contains('Sky').then(option => {
//    cy.wrap(option).contains('Sky');  
//     option[0].click(); 
//     })
cy.get('.c-btn > svg').click();
cy.get('.c-editorial-layer__title').should('contain.text','Sky Shop');
})
